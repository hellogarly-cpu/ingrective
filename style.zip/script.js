async function fetchProduct() {
  const barcode = document.getElementById('barcodeInput').value.trim();
  const resultDiv = document.getElementById('result');
  
  if (!barcode) {
    resultDiv.innerHTML = "<p>Please enter a barcode.</p>";
    return;
  }

  resultDiv.innerHTML = "<p>Loading...</p>";

  try {
    const response = await fetch(`https://world.openfoodfacts.org/api/v0/product/${barcode}.json`);
    const data = await response.json();

    if (data.status === 1) {
      const product = data.product;
      resultDiv.innerHTML = `
        <h2>${product.product_name || "Unknown Product"}</h2>
        <p><strong>Ingredients:</strong> ${product.ingredients_text || "No ingredients listed."}</p>
        <p><strong>Categories:</strong> ${product.categories || "N/A"}</p>
      `;
    } else {
      resultDiv.innerHTML = `<p>Product not found. Please check the barcode.</p>`;
    }
  } catch (error) {
    resultDiv.innerHTML = `<p>Error fetching product information.</p>`;
  }
}
